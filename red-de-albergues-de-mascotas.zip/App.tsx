
import React from 'react';
import { Navbar } from './components/Navbar';
import { Hero } from './components/Hero';
import { Stats } from './components/Stats';
import { MapSection } from './components/MapSection';
import { WaysToHelp } from './components/WaysToHelp';
import { Newsletter } from './components/Newsletter';
import { Footer } from './components/Footer';

const App: React.FC = () => {
  return (
    <div className="min-h-screen flex flex-col selection:bg-primary/30 selection:text-text-dark">
      <Navbar />
      <main className="flex-1">
        <Hero />
        <Stats />
        <MapSection />
        <WaysToHelp />
        <Newsletter />
      </main>
      <Footer />
    </div>
  );
};

export default App;
