
import { NavItem, StatItem, Shelter } from './types';

export const NAV_ITEMS: NavItem[] = [
  { label: 'Albergues', href: '#' },
  { label: 'Adoptar', href: '#' },
  { label: 'Voluntariado', href: '#' },
  { label: 'Donar', href: '#' },
];

export const STATS: StatItem[] = [
  { value: '500+', label: 'Albergues Asociados' },
  { value: '12k+', label: 'Mascotas en adopción' },
  { value: '85k', label: 'Adopciones logradas' },
  { value: '2.5k', label: 'Voluntarios activos' },
];

export const FEATURED_SHELTERS: Shelter[] = [
  {
    id: '1',
    name: 'Santuario La Esperanza',
    location: 'Valencia, España',
    isVerified: true,
    dogCount: 42,
    catCount: 18,
    imageUrl: 'https://picsum.photos/seed/shelter1/600/400',
  },
  {
    id: '2',
    name: 'Asociación Gatos Felices',
    location: 'Barcelona, España',
    isVerified: true,
    dogCount: 0,
    catCount: 64,
    imageUrl: 'https://picsum.photos/seed/shelter2/600/400',
  },
];
