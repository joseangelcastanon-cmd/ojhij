
export interface Shelter {
  id: string;
  name: string;
  location: string;
  isVerified: boolean;
  dogCount: number;
  catCount: number;
  imageUrl: string;
}

export interface NavItem {
  label: string;
  href: string;
}

export interface StatItem {
  value: string;
  label: string;
}
