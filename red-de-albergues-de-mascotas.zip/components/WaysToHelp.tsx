
import React from 'react';

const HELP_CARDS = [
  {
    title: 'Encuentra a tu mejor amigo',
    desc: 'Inicia el proceso de adopción y dale un hogar a un animal que lo necesita desesperadamente.',
    btn: 'Quiero Adoptar',
    icon: 'favorite',
    color: 'bg-rose-50 text-rose-500',
  },
  {
    title: 'Regala tu tiempo',
    desc: 'Únete como voluntario en tu albergue más cercano y marca una diferencia real día tras día.',
    btn: 'Hacerme Voluntario',
    icon: 'volunteer_activism',
    color: 'bg-primary/10 text-primary',
  },
  {
    title: 'Apoya nuestra causa',
    desc: 'Tus donaciones ayudan a financiar comida, medicinas y mejoras vitales en las instalaciones.',
    btn: 'Donar Ahora',
    icon: 'payments',
    color: 'bg-blue-50 text-blue-500',
  },
];

export const WaysToHelp: React.FC = () => {
  return (
    <section className="px-4 md:px-10 lg:px-40 py-24 bg-white">
      <div className="max-w-[1280px] mx-auto text-center mb-16">
        <h3 className="text-4xl md:text-5xl font-black mb-5 tracking-tight">¿Cómo quieres ayudar hoy?</h3>
        <p className="text-zinc-400 text-lg max-w-2xl mx-auto leading-relaxed font-medium">Cada pequeña acción cuenta para mejorar el futuro de miles de animales esperando una oportunidad.</p>
      </div>
      
      <div className="max-w-[1280px] mx-auto grid md:grid-cols-3 gap-10">
        {HELP_CARDS.map((card) => (
          <div key={card.title} className="flex flex-col items-center p-10 bg-[#f9fafb] rounded-[2.5rem] group border border-transparent hover:border-primary/20 transition-all hover:bg-white hover:shadow-2xl hover:-translate-y-2">
            <div className={`w-20 h-20 ${card.color} rounded-3xl flex items-center justify-center mb-8 group-hover:scale-110 transition-transform shadow-sm`}>
              <span className="material-symbols-outlined text-4xl">{card.icon}</span>
            </div>
            <h4 className="text-2xl font-black mb-4 text-center">{card.title}</h4>
            <p className="text-zinc-500 text-base text-center mb-10 leading-relaxed">{card.desc}</p>
            <button className="w-full h-14 rounded-2xl bg-primary text-text-dark font-black hover:bg-primary-dark transition-all shadow-lg shadow-primary/20 active:scale-95">
              {card.btn}
            </button>
          </div>
        ))}
      </div>
    </section>
  );
};
