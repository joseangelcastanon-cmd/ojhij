
import React from 'react';

export const Newsletter: React.FC = () => {
  return (
    <section className="px-4 md:px-10 lg:px-40 py-10">
      <div className="max-w-[1280px] mx-auto bg-primary rounded-[3rem] p-10 md:p-20 relative overflow-hidden flex flex-col items-center text-center shadow-2xl shadow-primary/30">
        {/* Decorations */}
        <div className="absolute -top-20 -right-20 w-80 h-80 bg-white/10 rounded-full blur-[100px]" />
        <div className="absolute -bottom-20 -left-20 w-80 h-80 bg-white/10 rounded-full blur-[100px]" />
        
        <h3 className="text-text-dark text-4xl md:text-5xl font-black mb-6 tracking-tight">Únete a nuestra comunidad</h3>
        <p className="text-text-dark/70 text-lg md:text-xl font-medium max-w-2xl mb-12 leading-relaxed">
          Recibe noticias sobre adopciones exitosas, eventos exclusivos y consejos expertos para el cuidado de tus mascotas.
        </p>
        
        <form className="w-full max-w-lg flex flex-col sm:row gap-3 relative z-10" onSubmit={(e) => e.preventDefault()}>
          <div className="flex flex-col sm:flex-row gap-3">
            <input 
              className="flex-1 h-16 rounded-2xl border-none px-8 text-text-dark font-medium focus:ring-4 focus:ring-text-dark/10 shadow-xl" 
              placeholder="Tu mejor correo electrónico" 
              type="email"
            />
            <button className="h-16 px-10 bg-text-dark text-white font-black rounded-2xl transition-all hover:scale-105 active:scale-95 shadow-xl shadow-text-dark/20">
              Suscribirse
            </button>
          </div>
        </form>
      </div>
    </section>
  );
};
