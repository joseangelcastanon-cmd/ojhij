
import React from 'react';

export const Hero: React.FC = () => {
  return (
    <section className="px-4 md:px-10 lg:px-40 py-10">
      <div className="max-w-[1280px] mx-auto">
        <div className="relative min-h-[580px] flex flex-col items-center justify-center gap-12 rounded-3xl overflow-hidden shadow-2xl">
          {/* Background Image */}
          <div 
            className="absolute inset-0 bg-cover bg-center -z-10" 
            style={{ 
              backgroundImage: 'linear-gradient(rgba(0, 0, 0, 0.4) 0%, rgba(0, 0, 0, 0.6) 100%), url("https://images.unsplash.com/photo-1548199973-03cce0bbc87b?q=80&w=2069&auto=format&fit=crop")' 
            }}
          />
          
          <div className="flex flex-col gap-6 text-center px-6 max-w-4xl">
            <h1 className="text-white text-5xl md:text-7xl font-black leading-[1.1] tracking-tight">
              Conectando albergues.<br/>Salvando vidas.
            </h1>
            <p className="text-white/90 text-xl md:text-2xl font-normal max-w-2xl mx-auto leading-relaxed">
              La red nacional que une a protectores, voluntarios y familias para transformar el bienestar animal en España.
            </p>
          </div>

          {/* Search Box */}
          <div className="w-full max-w-4xl px-4">
            <div className="bg-white p-5 rounded-2xl shadow-2xl flex flex-col md:flex-row gap-5 items-end">
              <label className="flex flex-col flex-1 w-full">
                <span className="text-[10px] font-bold uppercase tracking-widest text-zinc-400 mb-2 px-1">Provincia</span>
                <select className="w-full h-14 rounded-xl border-[#d7e7cf] bg-zinc-50 text-sm focus:ring-primary focus:border-primary">
                  <option>Todas las provincias</option>
                  <option>Madrid</option>
                  <option>Barcelona</option>
                  <option>Valencia</option>
                  <option>Sevilla</option>
                </select>
              </label>
              
              <label className="flex flex-col flex-1 w-full">
                <span className="text-[10px] font-bold uppercase tracking-widest text-zinc-400 mb-2 px-1">Tipo de Albergue</span>
                <select className="w-full h-14 rounded-xl border-[#d7e7cf] bg-zinc-50 text-sm focus:ring-primary focus:border-primary">
                  <option>Todos los tipos</option>
                  <option>Protectora</option>
                  <option>Santuario</option>
                  <option>Centro Municipal</option>
                </select>
              </label>

              <button className="w-full md:w-auto flex h-14 px-10 items-center justify-center rounded-xl bg-primary text-text-dark font-black transition-all hover:bg-primary-dark hover:scale-[1.02] active:scale-95 whitespace-nowrap">
                <span className="material-symbols-outlined mr-2">search</span>
                Buscar Albergues
              </button>
            </div>
          </div>
        </div>
      </div>
    </section>
  );
};
