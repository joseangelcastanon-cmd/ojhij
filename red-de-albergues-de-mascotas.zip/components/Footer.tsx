
import React from 'react';

export const Footer: React.FC = () => {
  return (
    <footer className="bg-zinc-100 border-t border-zinc-200 px-4 md:px-10 lg:px-40 py-24">
      <div className="max-w-[1280px] mx-auto grid grid-cols-1 md:grid-cols-4 gap-16">
        <div className="col-span-1">
          <div className="flex items-center gap-3 mb-8">
            <div className="text-primary w-10 h-10">
              <svg fill="currentColor" viewBox="0 0 48 48" xmlns="http://www.w3.org/2000/svg">
                <path d="M36.7273 44C33.9891 44 31.6043 39.8386 30.3636 33.69C29.123 39.8386 26.7382 44 24 44C21.2618 44 18.877 39.8386 17.6364 33.69C16.3957 39.8386 14.0109 44 11.2727 44C7.25611 44 4 35.0457 4 24C4 12.9543 7.25611 4 11.2727 4C14.0109 4 16.3957 8.16144 17.6364 14.31C18.877 8.16144 21.2618 4 24 4C26.7382 4 29.123 8.16144 30.3636 14.31C31.6043 8.16144 33.9891 4 36.7273 4C40.7439 4 44 12.9543 44 24C44 35.0457 40.7439 44 36.7273 44Z"></path>
              </svg>
            </div>
            <h2 className="text-2xl font-black">Red de Albergues</h2>
          </div>
          <p className="text-base text-zinc-500 font-medium leading-relaxed">
            Trabajamos incansablemente por el bienestar animal en cada rincón de España. Unidos somos más fuertes.
          </p>
        </div>

        <div>
          <h4 className="font-black text-lg mb-8 tracking-tight">Plataforma</h4>
          <ul className="space-y-4 text-zinc-500 font-semibold">
            <li><a className="hover:text-primary transition-colors" href="#">Directorio de Albergues</a></li>
            <li><a className="hover:text-primary transition-colors" href="#">Busca una Mascota</a></li>
            <li><a className="hover:text-primary transition-colors" href="#">Mapa Interactivo</a></li>
            <li><a className="hover:text-primary transition-colors" href="#">Documentación</a></li>
          </ul>
        </div>

        <div>
          <h4 className="font-black text-lg mb-8 tracking-tight">Recursos</h4>
          <ul className="space-y-4 text-zinc-500 font-semibold">
            <li><a className="hover:text-primary transition-colors" href="#">Consejos de Adopción</a></li>
            <li><a className="hover:text-primary transition-colors" href="#">Marco Legal</a></li>
            <li><a className="hover:text-primary transition-colors" href="#">Blog de Impacto</a></li>
            <li><a className="hover:text-primary transition-colors" href="#">FAQs</a></li>
          </ul>
        </div>

        <div>
          <h4 className="font-black text-lg mb-8 tracking-tight">Contacto</h4>
          <ul className="space-y-6 text-zinc-500 font-semibold">
            <li className="flex items-center gap-3">
              <span className="w-10 h-10 bg-white rounded-xl flex items-center justify-center shadow-sm">
                <span className="material-symbols-outlined text-primary text-xl">mail</span>
              </span>
              info@redalbergues.es
            </li>
            <li className="flex items-center gap-3">
              <span className="w-10 h-10 bg-white rounded-xl flex items-center justify-center shadow-sm">
                <span className="material-symbols-outlined text-primary text-xl">phone</span>
              </span>
              +34 900 123 456
            </li>
            <li className="flex gap-4 mt-8 pt-4">
              <a className="w-12 h-12 bg-white rounded-2xl flex items-center justify-center hover:bg-primary hover:text-white transition-all shadow-sm" href="#">
                <span className="material-symbols-outlined text-xl">share</span>
              </a>
              <a className="w-12 h-12 bg-white rounded-2xl flex items-center justify-center hover:bg-primary hover:text-white transition-all shadow-sm" href="#">
                <span className="material-symbols-outlined text-xl">group</span>
              </a>
            </li>
          </ul>
        </div>
      </div>
      
      <div className="max-w-[1280px] mx-auto mt-24 pt-10 border-t border-zinc-200 flex flex-col md:flex-row justify-between gap-6 text-sm text-zinc-400 font-semibold">
        <p>© 2024 Red de Albergues de Mascotas de España. Todos los derechos reservados.</p>
        <div className="flex gap-8">
          <a className="hover:text-primary transition-colors" href="#">Política de Privacidad</a>
          <a className="hover:text-primary transition-colors" href="#">Términos de Uso</a>
          <a className="hover:text-primary transition-colors" href="#">Cookies</a>
        </div>
      </div>
    </footer>
  );
};
