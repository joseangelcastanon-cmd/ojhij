
import React from 'react';
import { STATS } from '../constants';

export const Stats: React.FC = () => {
  return (
    <div className="bg-primary/5 py-12 border-y border-primary/10">
      <div className="max-w-[1280px] mx-auto px-10 grid grid-cols-2 md:grid-cols-4 gap-12 text-center">
        {STATS.map((stat) => (
          <div key={stat.label} className="group cursor-default">
            <p className="text-4xl font-black text-primary mb-1 group-hover:scale-110 transition-transform">
              {stat.value}
            </p>
            <p className="text-sm font-semibold text-text-dark/60 tracking-tight uppercase">
              {stat.label}
            </p>
          </div>
        ))}
      </div>
    </div>
  );
};
