
import React from 'react';
import { FEATURED_SHELTERS } from '../constants';

export const MapSection: React.FC = () => {
  return (
    <section className="px-4 md:px-10 lg:px-40 py-20 bg-[#f9fafb]">
      <div className="max-w-[1280px] mx-auto">
        <div className="flex flex-col md:flex-row justify-between items-end mb-12 gap-6">
          <div className="max-w-xl">
            <span className="text-primary font-bold tracking-[0.2em] uppercase text-xs">Red Nacional</span>
            <h3 className="text-4xl font-black mt-2 leading-tight">Encuentra un albergue en tu zona</h3>
            <p className="mt-3 text-zinc-500 text-lg">Explora el mapa interactivo o revisa nuestras protectoras destacadas por su labor reciente.</p>
          </div>
          <button className="text-primary font-bold flex items-center gap-2 hover:text-primary-dark group transition-colors">
            Ver todos en el mapa 
            <span className="material-symbols-outlined transition-transform group-hover:translate-x-1">arrow_forward</span>
          </button>
        </div>

        <div className="grid lg:grid-cols-3 gap-10">
          {/* Map Area */}
          <div className="lg:col-span-2 relative h-[550px] rounded-[2rem] overflow-hidden shadow-lg border-4 border-white">
            <div className="absolute inset-0 bg-zinc-200">
               <img 
                src="https://images.unsplash.com/photo-1524661135-423995f22d0b?auto=format&fit=crop&q=80&w=1474" 
                className="w-full h-full object-cover opacity-60 grayscale-[0.5]"
                alt="Map Background"
              />
            </div>
            
            {/* Map Controls */}
            <div className="absolute top-6 left-6 flex flex-col gap-3">
              <button className="w-12 h-12 bg-white rounded-2xl shadow-xl flex items-center justify-center text-zinc-400 hover:text-primary transition-all">
                <span className="material-symbols-outlined">add</span>
              </button>
              <button className="w-12 h-12 bg-white rounded-2xl shadow-xl flex items-center justify-center text-zinc-400 hover:text-primary transition-all">
                <span className="material-symbols-outlined">remove</span>
              </button>
            </div>

            {/* Custom Markers */}
            <div className="absolute top-1/2 left-1/3 group cursor-pointer">
              <div className="relative flex flex-col items-center">
                <div className="bg-primary text-text-dark px-4 py-1.5 rounded-full text-xs font-black shadow-xl mb-2 translate-y-2 opacity-0 group-hover:opacity-100 group-hover:-translate-y-1 transition-all">
                  Protectora Madrid
                </div>
                <div className="w-10 h-10 bg-primary rounded-full flex items-center justify-center shadow-lg border-4 border-white group-hover:scale-125 transition-transform">
                  <span className="material-symbols-outlined text-white text-xl material-symbols-fill">pets</span>
                </div>
              </div>
            </div>

             <div className="absolute top-1/4 right-1/4 group cursor-pointer">
               <div className="w-8 h-8 bg-primary/40 rounded-full flex items-center justify-center shadow-md border-2 border-white group-hover:scale-125 transition-transform backdrop-blur-sm">
                 <div className="w-2 h-2 bg-primary rounded-full" />
               </div>
            </div>
          </div>

          {/* Featured List */}
          <div className="flex flex-col gap-8">
            <h4 className="font-black text-2xl px-2">Protectoras Destacadas</h4>
            
            {FEATURED_SHELTERS.map((shelter) => (
              <div key={shelter.id} className="bg-white rounded-3xl overflow-hidden shadow-sm hover:shadow-xl border border-zinc-100 transition-all group">
                <div 
                  className="h-40 bg-cover bg-center" 
                  style={{ backgroundImage: `url(${shelter.imageUrl})` }}
                />
                <div className="p-6">
                  <div className="flex justify-between items-start mb-1">
                    <h5 className="font-bold text-lg group-hover:text-primary transition-colors">{shelter.name}</h5>
                    {shelter.isVerified && (
                      <span className="bg-primary/10 text-primary-dark text-[10px] font-black px-3 py-1 rounded-full uppercase tracking-wider">Verificado</span>
                    )}
                  </div>
                  <p className="text-sm text-zinc-400 flex items-center gap-1 mb-6">
                    <span className="material-symbols-outlined text-sm">location_on</span> {shelter.location}
                  </p>
                  
                  <div className="flex justify-between items-center border-t border-zinc-50 pt-5">
                    <div className="flex gap-6">
                      <div className="text-center">
                        <p className="text-lg font-black">{shelter.dogCount}</p>
                        <p className="text-[10px] font-bold text-zinc-400 uppercase tracking-widest">Perros</p>
                      </div>
                      <div className="text-center">
                        <p className="text-lg font-black">{shelter.catCount}</p>
                        <p className="text-[10px] font-bold text-zinc-400 uppercase tracking-widest">Gatos</p>
                      </div>
                    </div>
                    <button className="bg-primary/10 hover:bg-primary text-primary hover:text-white px-5 py-2.5 rounded-xl text-xs font-black transition-all">
                      Ver Perfil
                    </button>
                  </div>
                </div>
              </div>
            ))}
          </div>
        </div>
      </div>
    </section>
  );
};
